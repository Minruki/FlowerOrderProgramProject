package test;

public class RefObject {

	private int numId;
	private String name;
	
	public int getNumId() {
		return numId;
	}

	public void setNumId(int numId) {
		this.numId = numId;
	}
	
	
}
